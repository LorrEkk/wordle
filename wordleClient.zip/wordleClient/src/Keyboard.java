import java.util.*;
import java.util.Dictionary;

public class Keyboard { //klasa odpowiada za klawiaturę w dolnej części okna głównego
    //0-nie użyte, 1-ok, 2-jest ale nie w tym miejscu, 3-użyte i nie ma nigdzie
    Dictionary<Character, Integer> keyboardDictionary = new Hashtable<>();

    public Keyboard() {
        char[] letters = {'A', 'Ą', 'B', 'C', 'Ć', 'D', 'E', 'Ę', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'Ł', 'M', 'N', 'Ń', 'O', 'Ó', 'P', 'Q', 'R', 'S', 'Ś', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'Ź', 'Ż'};

        for (char l : letters) {
            keyboardDictionary.put(l, 0);
        }
    }

    public void setLetterUsage(char letter, int usage) {
        int u = keyboardDictionary.get(letter);

        if (u == 0) {
            keyboardDictionary.put(letter, usage);
        } else if (u == 2 && usage == 1) {
            keyboardDictionary.put(letter, usage);
        }
    }

    public int getLetterUsage(char letter) {
        return keyboardDictionary.get(letter);
    }

    public void resetKeyboardDictionary() {
        Enumeration<Character> items = keyboardDictionary.keys();

        while (items.hasMoreElements()) {
            char key = items.nextElement();
            keyboardDictionary.put(key, 0);
        }
    }
}
